//
//  ChildLongPress.h
//  DBSphereTagCloud
//
//  Created by youngstar on 2017/4/16.
//  Copyright © 2017年 Xinbao Dong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChildLongPress : UILongPressGestureRecognizer
@property (nonatomic, assign) NSInteger flag;

@end
