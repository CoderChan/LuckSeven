//
//  ChildGestureRecognizer.h
//  TogetherInvest
//
//  Created by youngstar on 15/11/20.
//  Copyright © 2015年 Zhong Tou. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ChildGestureRecognizer : UITapGestureRecognizer

@property (nonatomic, strong) UIButton *button;


@end
